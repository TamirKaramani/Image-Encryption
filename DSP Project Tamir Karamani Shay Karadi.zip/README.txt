Shai Karadi & Tamir Karamani DSP Project

Instructions:

a. Install DWT based encryption technique APP
b. start MATLAB and open the APP using "apps" TAB.

RAR file contains:
a. DSP.mlapp is the main code file.
b. BlockPermute.m, PixelPermute.m, InverseKey.m, Slice.m are the MATLAB functions we created.
c. PowerPoint file of the project.
d. PDF File of The proposed method article.
e.PDF file of encryption article which is used in the Proposed Method article.

